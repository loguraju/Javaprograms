package com.example.demo.others;


class Ani {
    static void sound() { //static
        System.out.println("static: Animal makes a sound");
    }
}

class Animals {
    void sound() {
        System.out.println("Dynamic: Animal makes a sound");
    }
}

class Cat extends Animals {
    void sound() {
        System.out.println("Dynamic: Dog barks");
    }
}

public class Binding {
    public static void main(String[] args) {
    	Ani.sound(); // Statis - Resolved at compile time
        
    	Animals a = new Cat(); // Reference is Animal, object is Dog
        a.sound(); // Dynamic - Resolved at runtime
    }
}
