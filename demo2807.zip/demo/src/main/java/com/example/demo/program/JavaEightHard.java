package com.example.demo.program;

import java.util.*;
import java.util.stream.*;

public class JavaEightHard {
	
	public static void main(String[] args) {	
	   
	String s9= "madam";
	
	boolean res1 = IntStream.range(0, s9.length()/2).allMatch(i -> s9.charAt(i) == s9.charAt(s9.length() - i -1));		
	if (res1) {
       System.out.println(s9 + " - is a palindrome.");
   } else {
       System.out.println(s9 + " - is not a palindrome.");
   }
	
/* 	
  
*IntStream.range(0, s.length() / 2)
    Creates a stream of integers from 0 to s.length()/2 - 1.This covers the first half of the string.
*i -> s.charAt(i) == s.charAt(s.length() - i - 1) 
    For each index i, it compares the character at position i with the character at the mirror 
                                                      position from the end: s.length() - i - 1.
*Compare s.charAt(0) with s.charAt(4) → 'm' == 'm'

*/ 
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

String str1 = "i am going to school in banglore";
String esr = Arrays.stream(str1.split(" ")).map(word -> new StringBuilder(word).reverse().toString()).collect(Collectors.joining(" "));

System.out.println("Each word reverse in string sentence: " + esr);

//---------------------------------------------------------------------------------------------------------------------
String s11 = "my hello java world.";
String s12 = "hello my spring boot.";

Set<String> w1 = Arrays.stream(s11.toLowerCase().split("\\W+")).collect(Collectors.toSet());
Set<String> w2 = Arrays.stream(s12.toLowerCase().split("\\W+")).collect(Collectors.toSet());

w1.retainAll(w2);
System.out.println("Common words in two string sentence: " + w1);

//split("\\W+") = splits the sentence into words, ignoring punctuation.
//retainAll() = keeps only the words that are common in both sets.

//---------------------------------------------------------------------------------------------------------------------------------
    int[] a1 = new int[] {4, 2, 7, 1, 6};         
    int[] b1 = new int[] {8, 3, 9, 5, 6 };
         
    int[] c1 = IntStream.concat(IntStream.of(a1), IntStream.of(b1)).sorted().toArray();
    System.out.println("Merge two unsorted arrays into single: " + Arrays.toString(c1));
    
    int[] c2 = IntStream.concat(IntStream.of(a1), IntStream.of(b1)).sorted().distinct().toArray();
    System.out.println("Merge two unsorted arrays into single without Duplicate: " + Arrays.toString(c2));
    
//--------------------------------------------------------------------------------------------------------------------------------------------------------

   String s21 = "http://localhost:PORT/";
   String s22 = "http://localhost:PORT/user";

   int minLength = Math.min(s21.length(), s22.length());

   String commonPrefix = IntStream.range(0, minLength).takeWhile(i -> s21.charAt(i) == s22.charAt(i))
                      .mapToObj(i -> String.valueOf(s21.charAt(i))).collect(Collectors.joining());

   System.out.println("\nCommon prefix: " + commonPrefix);
 //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   
   System.out.println("Fibonacci series:");	

   Stream.iterate(new int[] {0, 1}, f -> new int[] {f[1], f[0]+f[1]})
                                .limit(10).map(f -> f[0]).forEach(i -> System.out.print(i+" "));
   /*
     *Stream.iterate(new int[] {0, 1}, f -> new int[] {f[1], f[0] + f[1]})

      *Starts with an array {0, 1} — the first two Fibonacci numbers.
      Each iteration produces a new array where:
      f[1] becomes the new first element (the previous second number),
      f[0] + f[1] becomes the new second element (the sum of the previous two).
      This effectively shifts the Fibonacci sequence forward.

   *.limit(10) = Limits the stream to the first 10 elements.
   *.map(f -> f[0]) = Extracts the first number of each array — which is the current Fibonacci number.
   *.forEach(i -> System.out.print(i + " ")) = Prints each number with a space


    */
   //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

           int[] a11 = {1, 2, 4, 6,8};

           // Find min and max
           int min = Arrays.stream(a11).min().orElse(0);
           int max = Arrays.stream(a11).max().orElse(0);

           // Convert array to list for easy lookup
           List<Integer> list = Arrays.stream(a11).boxed().collect(Collectors.toList()); 
           
           //mapToObj() instead of .boxed() = .mapToObj(Integer::valueOf) 

           // Find missing numbers
           List<Integer> missing = IntStream.rangeClosed(min, max)
                   .filter(i -> !list.contains(i))
                   .boxed()  // converts to Integer objects
                   .collect(Collectors.toList());

           System.out.println("\nMissing numbers: " + missing);

           // Hardcode Missing numbers          
           
           List<Integer> hmissing = IntStream.rangeClosed(1, 10)
               .filter(i -> Arrays.stream(a11).noneMatch(x -> x == i))
               .boxed()
               .collect(Collectors.toList());
           System.out.println("\n Hardcode Missing numbers: " + hmissing);
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
}

}
