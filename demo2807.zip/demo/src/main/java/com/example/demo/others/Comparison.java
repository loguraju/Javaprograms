package com.example.demo.others;

// == address comparison
// equals  content comparison
public class Comparison {
    public static void main(String[] args) {
        String a = "hello";
        String b = "hello";
        String c = new String("hello");
        String d = new String("hello");
        
        
        System.out.println(a.hashCode());
        System.out.println(b.hashCode());
        System.out.println(c.hashCode());
        System.out.println(d.hashCode());
        
        
        System.out.println(a == b); // true (Same reference from string pool)
        System.out.println(a == c); // false (different objects)
        System.out.println(c == d); // false (different objects)
        System.out.println(c.equals(d));  // true (same content)
    }
}

