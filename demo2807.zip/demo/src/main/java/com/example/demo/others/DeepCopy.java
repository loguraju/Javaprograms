package com.example.demo.others;

class Address {
    String city;

    Address(String city) {
        this.city = city;
    }
}

class Persons implements Cloneable {
    String name;
    Address address;

    Persons(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public Object clone() throws CloneNotSupportedException {
        Address clonedAddress = new Address(this.address.city);
        return new Persons(this.name, clonedAddress); // deep copy ( create new obj and copy the old to into new obj)
    }
}

public class DeepCopy{
    public static void main(String[] args) throws CloneNotSupportedException {
        Address address = new Address("Chennai");
        Persons p1 = new Persons("Loganathan", address);
        Persons p2 = (Persons) p1.clone();

        p2.name = "Raju";
        p2.address.city = "Bangalore";

        System.out.println("p1 city: " + p1.address.city); // Chennai
        System.out.println("p2 city: " + p2.address.city); // Bangalore
    }
}
