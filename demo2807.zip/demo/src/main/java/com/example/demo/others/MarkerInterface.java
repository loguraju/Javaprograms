package com.example.demo.others;

import java.io.*;

//does not contain any methods or fields. It is used to mark a class.
//so that it can be treated differently by the JVM or other frameworks.
//Ex Serializable,Cloneable & Remote
class Students implements Serializable,Cloneable {
    int id;
    String name;

    public Students(int id, String name) {
        this.id = id;
        this.name = name;
    }    

    // Must override clone() to enable cloning
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}

public class MarkerInterface{
    public static void main(String[] args) {
    	
 //Serializable(object convert into bytstream)
        try {
            Students s = new Students(101, "Raju");
            FileOutputStream fos = new FileOutputStream("student.txt");//saving the serialized object to a file named student.txt
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(s); // Serialization
            oos.close();
            fos.close();
            System.out.println("Object has been serialized.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        
//DeSerializable(bystream convert into object)  --> its not part of marker interface example
        try {
            FileInputStream fis = new FileInputStream("student.ser"); //Opens the file student.ser that contains the serialized object.
            ObjectInputStream ois = new ObjectInputStream(fis);
            Students s2 = (Students) ois.readObject(); // Deserialization
            ois.close();
            fis.close();
            System.out.println("Deserialized Student: " + s2.id + ", " + s2.name);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

//Cloneable
        try {
            Students s1 = new Students(101, "Raju");
            Students s2 = (Students) s1.clone(); // Cloning s1 object into s2

            System.out.println("Original: " + s1.id + " " + s1.name);
            System.out.println("Cloned: " + s2.id + " " + s2.name);
        } catch (CloneNotSupportedException e) {
            System.out.println("Cloning not supported.");
        }

    }
}

