package com.example.demo.program;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.*;

public class JavaEightEasyInt {
	
	public static void main(String[] args) {	   
		
		List<Integer> n1 = Arrays.asList(11,22,44,11,52,3,5);
		
		List<Integer> n2 = Arrays.asList(11,33,36,46,52,32,99,79);					
		 
//------------------------------------------------------------------------------------------------------
		List<Integer> r1 = n1.stream().distinct().collect(Collectors.toList());		
		System.out.println("remove Dublicate :"+ r1);
//------------------------------------------------------------------------------------------------------
		Integer r2 = n1.stream().sorted().findFirst().get();		
		System.out.println("List min value :"+ r2);		
		
		Integer r3 = n1.stream().sorted(Comparator.reverseOrder()).findFirst().get();
		System.out.println("List max value :"+ r3);
		
		int[] a11 = {1, 2, 4, 6,8};

        // Find min and max
        int min = Arrays.stream(a11).min().orElse(0);
        int max = Arrays.stream(a11).max().orElse(0);
        
        System.out.println("Array min value :"+ min);
        System.out.println("Array max value :"+ max);
//------------------------------------------------------------------------------------------------------------
		List<Integer> r4 = n1.stream().filter(o -> o%2==0).collect(Collectors.toList());
		System.out.println("even values :"+ r4);				

		List<Integer> r5 = n1.stream().filter(o -> o%2!=0).collect(Collectors.toList());
		System.out.println("odd values :"+ r5);	
//-------------------------------------------------------------------------------------------------------------
		List<Integer> r6 = n1.stream().sorted().limit(3).collect(Collectors.toList());
		System.out.println("min 3 values :"+ r6);		

		List<Integer> r7 = n1.stream().sorted(Comparator.reverseOrder()).limit(3).collect(Collectors.toList());
		System.out.println("max 3 values :"+ r7);		
//-------------------------------------------------------------------------------------------------------------
		List<Integer> r8 = n1.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println("reverse order :"+ r8);	
//-------------------------------------------------------------------------------------------------------------
		Integer r9 = n1.stream().sorted().skip(1).findFirst().get();
		System.out.println("2nd lowest value :"+ r9);
		
		Integer rs9 = n1.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
		System.out.println("2nd Highest value :"+ rs9);		
//-------------------------------------------------------------------------------------------------------------
		int[] arr = {45, 12, 56, 15, 24, 75, 31, 89};		
		
		int r01 = IntStream.of(arr).sum();
		System.out.println("sum of value :"+ r01);		

		int r02 = IntStream.of(arr).reduce((a, b) -> a - b).orElse(0);
        System.out.println("Subtraction result(left to right):"+ r02);

		OptionalDouble r03 = IntStream.of(arr).average();
		System.out.println("average of value :"+ r03);
		
//-------------------------------------------------------------------------------------------------------------
		Integer r12 = n1.stream().skip(n1.size()-1).findFirst().get();
		//n1.get(n1.size() - 1);	//opn 2
		System.out.println("last element in array :"+ r12);
//-------------------------------------------------------------------------------------------------------------		
		
		Integer r13 = IntStream.rangeClosed(1,10).sum();
		System.out.println("sum of fst 10 natural numbers :" + r13);
		
		System.out.println("fst 10 even num :");
		IntStream.rangeClosed(1, 10).map(i -> i * 2).forEach(System.out::println);
		
		System.out.println("Range from 1 to 10: ");
		IntStream.range(1, 10).forEach(System.out::println);
		
		System.out.println("Range Closed from 1 to 10: ");
		IntStream.rangeClosed(1, 10).forEach(System.out::println);
//-------------------------------------------------------------------------------------------------------------
		List<Integer> r14 = n1.stream().filter(n2::contains).collect(Collectors.toList());
		System.out.println("Common element in array :" + r14);
//-------------------------------------------------------------------------------------------------------------
        List<Integer> n3 = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
	    List<Integer> square = n3.stream().map(n -> n * n).collect(Collectors.toList());
	    List<Integer> cube = n3.stream().map(n -> n * n *n).collect(Collectors.toList());
	    
	    System.out.println("Squares of Numbers : " + square);
	    System.out.println("Cube of Numbers : " + cube);
	    
		List<Integer> squareOdd = n3.stream().filter(n -> n % 2 != 0).map(n -> n * n).collect(Collectors.toList());
 
		System.out.println("Squares of Odd Numbers : " + squareOdd);
		
		List<Integer> squaresEven = n3.stream().filter(n -> n % 2 == 0).map(n -> n * n).collect(Collectors.toList());
		
		System.out.println("Squares of Odd Numbers : " + squaresEven);
//-------------------------------------------------------------------------------------------------------------
// Swapping without a third variable
         int a = 5;
         int b = 10;

 //System.out.println("Before swap: a = " + a + ", b = " + b);
         
 a = a + b; // a becomes 15 (5+10)
 b = a - b; // b becomes 5  (5-10)
 a = a - b; // a becomes 10 (15-5)

 System.out.println("After swap: a = " + a + ", b = " + b);
//---------------------------------------------------------------------------------------------------------------------		

int number = 123456;
int digiSum = String.valueOf(number)   // converts the number to a string.
               .chars()           // creates an  IntStream of ASCII values of each digit
               .map(c -> c - '0') // convert char to digit
               .sum();

System.out.println("Sum of digits: " + digiSum);


OptionalDouble digiAvg = String.valueOf(number)   // converts the number to a string.
.chars()           // creates an  IntStream of ASCII values of each digit
.map(c -> c - '0') // convert char to digit
.average();

System.out.println("Average of digits: " + digiAvg);
//---------------------------------------------------------------------------------------------------------------------
 
Predicate<Integer> pr  = io->(io>18);
System.out.println("Predicate Res: " + pr.test(10));
//---------------------------------------------------------------------------------------------------------------------

int age = 20;
String result = (age >= 18) ? "Yes" : "No";
System.out.println("Ternary operator: " + result);	
//---------------------------------------------------------------------------------------------------------------------	
	
List<Integer> list = Arrays.asList(11,22,44,11,52,3,5);

int size = list.size();
System.out.println("size: " + size);

double median;

if (size % 2 == 0) {
median = (list.get(size / 2 - 1) + list.get(size / 2)) / 2.0;
} else {
median = list.get(size / 2);
}

System.out.println("Median: " + median);	

//odd-> The median is the middle element after sorting.
//even-> The median is the average of the two middle elements after sorting.
//---------------------------------------------------------------------------------------------------------------------	
	
	}

}
