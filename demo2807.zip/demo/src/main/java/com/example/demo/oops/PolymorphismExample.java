package com.example.demo.oops;

//Superclass

//Method Overloading (Compile-time Polymorphism)
class Payment { 
 void pay(double amount) {
     System.out.println("Paying M1: " + amount);
 }

 void pay(double amount, String currency) {
     System.out.println("Paying M2: " + amount  + " " + currency);
 }
}

//Subclass for Cash Payment

// Method Overriding (Runtime Polymorphism)
class CashPayment extends Payment {
@Override
 void pay(double amount) {
     System.out.println("Paid using cash: " + amount);
 }
}

//Subclass for UPI Payment
class UPIPayment extends Payment {
 @Override
 void pay(double amount) {
     System.out.println("Paid using UPI:" + amount);
 }
}

//Subclass for Card Payment
class CardPayment extends Payment {
 @Override
 void pay(double amount) {
     System.out.println("Paid using card:" + amount);
 }
}

//Main class
public class PolymorphismExample {
 public static void main(String[] args) {
     // Method Overloading
     Payment basePayment = new Payment();
     basePayment.pay(1000);           // Overloaded method 1
     basePayment.pay(2000, "USD");             // Overloaded method 2

     // Method Overriding
     Payment p1 = new CashPayment();
     Payment p2 = new UPIPayment();
     Payment p3 = new CardPayment();

     p1.pay(500);   // Calls overridden method in CashPayment
     p2.pay(750);   // Calls overridden method in UPIPayment
     p3.pay(1200);  // Calls overridden method in CardPayment
 }
}
