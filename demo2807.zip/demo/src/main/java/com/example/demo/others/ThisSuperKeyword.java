package com.example.demo.others;



//This(Refers To Current class) 
//use - Access fields, call constructors
	class Student {
	    String name;
	    int age;

	    Student(String name, int age) {
	        this.name = name; // 'this' differentiates instance variable from parameter
	        this.age = age;
	    }

	    void display() {
	        System.out.println("Name: " + this.name + ", Age: " + this.age);
	    }
	}
	

//Super(Refers To Parent class)
//Use - Access parent constructor,Variable, methods, fields

	class Animal {
	    String name; //Variable

	    Animal(String name) {
	        this.name = name;
	        System.out.println("Animal constructor called");
	    }

	    void makeSound() { //Method
	        System.out.println("Animal makes a sound");
	    }
	}

	class Dog extends Animal {

	    Dog(String name) {
	        super(name); // Calls the constructor of the parent class (Animal)
	        System.out.println("Dog constructor called");
	    }

	    void display() {
	        System.out.println("Dog name: " + super.name); // Access parent class variable
	    }

	    void makeSound() {
	        super.makeSound(); // Calls parent class method
	        System.out.println("Dog barks");
	    }
	}

	public class ThisSuperKeyword {
	    public static void main(String[] args) {
	        Dog myDog = new Dog("Buddy");
	        myDog.display();
	        myDog.makeSound();
	    }
	}
