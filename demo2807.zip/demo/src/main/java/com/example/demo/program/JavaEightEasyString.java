package com.example.demo.program;

import java.util.*;
import java.util.stream.*;

public class JavaEightEasyString {
	
	public static void main(String[] args) {
		
		
		List<String> s1 = Arrays.asList("logu", "riyasree" , "nehan", "hi","hello", "Rajesh");
//-----------------------------------------------------------------------------------------------------------------------		
	    List<String> r15 = s1.stream().sorted(Comparator.comparing(String::length)).collect(Collectors.toList());
	    System.out.println("String increasing  order :" + r15);	
//-----------------------------------------------------------------------------------------------------------	    
	    List<String> r16 = s1.stream().sorted(Comparator.comparing(String::length).reversed()).collect(Collectors.toList());
	    System.out.println("String decreasing  order :"+ r16);
//------------------------------------------------------------------------------------------------------    
	    String r17 = s1.stream().collect(Collectors.joining(" "));
	    System.out.println("Joining [] as preffix and suffix : " + r17);		
//-------------------------------------------------------------------------------------------------------------
	    List<String> r18 = s1.stream().filter( s->s.startsWith("h")).collect(Collectors.toList());
	    System.out.println("Name Start with h :" + r18);
	    List<String> r188 = s1.stream().filter( s->s.endsWith("h")).collect(Collectors.toList());
	    System.out.println("Name End with h :" + r188);
//-------------------------------------------------------------------------------------------------------------
	    String r19 = s1.stream().filter( s->s.startsWith("h")).collect(Collectors.joining(" , "));
	    System.out.println("Concat the name start with h : " + r19);
//-------------------------------------------------------------------------------------------------------------	    
			
String sr1 = "hello";

String sr = new StringBuilder(sr1).reverse().toString();
System.out.println("String reverse : " + sr);

String sa = new StringBuilder(sr1).append(" nehan").toString();
System.out.println("String append : " + sa);

//-------------------------------------------------------------------------------------------------------------

String str = "apple | &banaNa | &Cherry ";
String res87 = str.replace("|", " ").toLowerCase();
System.out.println("Replace String: " + res87);

String res88 = str.replaceAll("[\\s|&]+", " ").toLowerCase();
System.out.println("Replace All String: " + res88);

//List<String> result = Arrays.stream(s.split("\\|")).map(String::trim).sorted(Comparator.comparing(String::length).reversed()).collect(Collectors.toList());
//20-------------------------------------------------------------------------------------------------------------
 List<String> res21 = s1.stream().map(String::toLowerCase).collect(Collectors.toList());
 System.out.println("String Lower case:" + res21);
          
 List<String> res22 = s1.stream().map(String::toUpperCase).collect(Collectors.toList());
 System.out.println("String Upper case:" + res22);

//------------------------------------------------------------------------------------------------------------------------
          

String s81 = "Java Concept Of The Day. |";

String s5 = s81.replaceAll("[\\s|.]+", "").toLowerCase();   

System.out.println("String Characters (Remove space and special char) : " + s5);


//-----------------------------------------------------------------------------------------------------------------------------------------    
   
Map<Character, Long> res = s5.chars().mapToObj(c->(char)c) //.filter(c -> c != ' ')   // Ignore spaces
		 .collect(Collectors.groupingBy(c -> c, LinkedHashMap::new,Collectors.counting()));

System.out.println("String Characters with count :" + res); 

System.out.println("Dublicate charactes with count :");

res.entrySet().stream().filter(e -> e.getValue() > 1).forEach(System.out::println);

// *entrySet().stream() = Converts the map entries (key-value pairs) into a stream.

System.out.println("Dublicate charactes  without count :");

res.entrySet().stream().filter(e -> e.getValue() > 1).map(e -> e.getKey()).forEach(System.out::println);

Character repeated = res.entrySet().stream().filter(e -> e.getValue() > 1) // == 1 means first non repeated character
		       .map(e -> e.getKey()).findFirst().get(); 

System.out.println("First repeated character in a string :" + repeated );     

/*
	 * Map<Character, Long> - count how many times each character appears
	 * key - character from the string , value - number of times that character.
	 * s5.chars() = Converts the string s5 into an Int of Unicode code points (integers representing characters).	 
	 * mapToObj(c -> (char) c) = Converts each Int of Unicode code point into a Character object. 	 
	 * collect(Collectors.groupingBy(...)) = Groups the characters by their identity.	 
	 * c -> c = in this case, it  refer grouping is done by the elements itself. // replace (Function.identity())	 
	 * Collectors.counting() = it counts how many times it appears.
*/
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------- 

String s3 = "hello";
List<Character> vow = Arrays.asList('a','e','i','o','u');
Long vowels = s3.chars().mapToObj(c->(char)c).filter(vow::contains).count();
System.out.println("vowels count in string: " + vowels);

//input.chars()  = Converts the String input into an Int (integers representing characters).
//.mapToObj(c -> (char) c) = Converts each Int code point into a Character object. 
     //This is necessary because chars() gives ints, but we want to work with Character objects for filtering.
}

}
