package com.example.demo.others;

import java.time.*;

//enumeration
//set of predefined constants
//useful when you have a fixed set of related values, like days of the week, directions, or states
public class Enum {
	
	public enum Day {
	    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
	}
	
    public static void main(String[] args) {

        LocalDate date = LocalDate.now();    // Gets the current date
        DayOfWeek today = date.getDayOfWeek(); // Gets the day of the week
        System.out.println("Today is: " + today);

        switch (today) {
            case MONDAY:
                System.out.println("Start of the work week!");
                break;
            case FRIDAY:
                System.out.println("Almost weekend!");
                break;
            default:
                System.out.println("Midweek day.");
        }
    }
}
