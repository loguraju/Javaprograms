package com.example.demo.Exception;

public class ExceptionHandle {
public static void main(String[] args) {



//Multiple catch blocks (one for each exception type)
    try {
            int[] numbers = {1, 2, 3};
            int ip1 = numbers[5] / 0; // May throw ArrayIndexOutOfBoundsException or ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic error: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("General error: " + e.getMessage());
        }

//Multiple catch blocks with | symbol (java 7)        
            try {
        	        String text = null;
                    System.out.println(text.length()); // May throw NullPointerException
                } catch (NullPointerException | ArithmeticException e) {
                    System.out.println("Caught exception: " + e.getMessage());
                }
            
            
//try-catch-finally-throw

	        try {
		            checkAge(15); // This will throw an exception
		            System.out.println("You are eligible to vote.");
		        } catch (IllegalArgumentException e) {
		            System.out.println("Caught an exception: " + e.getMessage());
		        } finally {
		            System.out.println("This block always executes."); 
		            }
		        }

		    public static void checkAge(int age) {
		        if (age < 18) {
		            throw new IllegalArgumentException("Age must be 18 or older to vote.");
		        }else {
		            System.out.println("Access granted.");
		        }
              }


	}

