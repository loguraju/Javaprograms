package com.example.demo.oops;

//Abstract class representing ATM
abstract class ATM {
 abstract void withdraw(double amount);
 abstract void checkBalance();

 void insertCard() {
     System.out.println("Card inserted. Welcome!");
 }
}

//SBI ATM implementation
class SBIATM extends ATM {
 private double balance = 10000;

 @Override
 void withdraw(double amount) {
     if (amount <= balance) {
         balance -= amount;
         System.out.println("SBI: Withdrawn ₹" + amount);
     } else {
         System.out.println("SBI: Insufficient balance.");
     }
 }

 @Override
 void checkBalance() {
     System.out.println("SBI: Current balance ₹" + balance);
 }
}

//Main class
public class AbstractionExample {
 public static void main(String[] args) {
     ATM atm1 = new SBIATM();     

     atm1.insertCard();
     atm1.withdraw(3000);
     atm1.checkBalance();

     System.out.println();
 }
}

