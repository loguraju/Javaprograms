package com.example.demo.oops;
//Parent class (superclass)
class Role {
 void read() {
     System.out.println("Role default Read access");
 }
}

//Child class (subclass) inherits from Animal
class Admin extends Role {
 void write() {
     System.out.println("Admin have write access");
 }
}

//Main class
public class InheritanceExample {
 public static void main(String[] args) {
	 Admin ad = new Admin();

     // Inherited method from Role class
	 ad.write();

     // Method from Admin class
	 ad.read();
 }
}

