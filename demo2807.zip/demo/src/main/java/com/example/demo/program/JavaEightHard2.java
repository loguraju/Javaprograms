package com.example.demo.program;

import java.util.*;
import java.util.stream.*;

public class JavaEightHard2 {
	
	public static void main(String[] args) {	

	
boolean res1 = IntStream.range(0, s9.length()/2).allMatch(i -> s9.charAt(i) == s9.charAt(s9.length() - i -1));		
if-else  System.out.println(s9 + " - is a palindrome.");	
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
String esr = Arrays.stream(str1.split(" ")).map(word -> new StringBuilder(word).reverse().toString())
          .collect(Collectors.joining(" ")); System.out.println("Each word reverse in string : " + esr);
//--------------------------------------------------------------------------------------------------------------------------------------------------------
Set<String> w1 = Arrays.stream(s11.toLowerCase().split("\\W+")).collect(Collectors.toSet());
Set<String> w2 = Arrays.stream(s12.toLowerCase().split("\\W+")).collect(Collectors.toSet());
w1.retainAll(w2);  System.out.println("Common words in two string sentence: " + w1);
//--------------------------------------------------------------------------------------------------------------------------------------------------------
int[] a1 = new int[] {4, 2, 7, 1, 6};    int[] b1 = new int[] {8, 3, 9, 5, 6 };         
int[] c1 = IntStream.concat(IntStream.of(a1), IntStream.of(b1)).sorted().toArray();
System.out.println("Merge two unsorted arrays into single: " + Arrays.toString(c1));     
//--------------------------------------------------------------------------------------------------------------------------------------------------------
String s21 = "http://localhost:PORT/"; String s22 = "http://localhost:PORT/user";
int minLength = Math.min(s21.length(), s22.length());
String commonPrefix = IntStream.range(0, minLength).takeWhile(i -> s21.charAt(i) == s22.charAt(i))
                      .mapToObj(i -> String.valueOf(s21.charAt(i))).collect(Collectors.joining());
 //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
System.out.println("Fibonacci series:");	
Stream.iterate(new int[] {0, 1}, f ->new int[]{f[1], f[0]+f[1]}).limit(10).map(f ->f[0]).forEach(i ->SOP(i+" "));
	
	
	
	
	}
}
