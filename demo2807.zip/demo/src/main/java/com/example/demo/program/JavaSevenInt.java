package com.example.demo.program;
import java.util.*;

public class JavaSevenInt {
public static void main(String[] args) {	

		
int[] numbers = {45, 12, 89, 5, 67, 22, 3};

// Sort the array
Arrays.sort(numbers);
System.out.println("After sort: "+ Arrays.toString(numbers));


System.out.println("Minimum 3 values:");
for (int i = 0; i < 3 && i < numbers.length; i++) {
System.out.println(numbers[i]);
   }

System.out.println("Maximum 3 values:");
for (int i = numbers.length - 1; i >= numbers.length - 3 && i >= 0; i--) {
 System.out.println(numbers[i]);
 }
//-------------------------------------------------------------------------------------------------------------	

System.out.println("odd numbers:");
for (int num : numbers) {
 if (num % 2 != 0) { 
System.out.println(num);
 }
 }

System.out.println("Even numbers:");
for (int num : numbers) {
	 if (num % 2 == 0) { 
	System.out.println(num);
	 }
	 }
//-------------------------------------------------------------------------------------------------------------	

System.out.println("Squares of  numbers:");

for (int num : numbers) {	 
	 int square = num * num;
	System.out.println(square);	
	 }

System.out.println("Squares of even numbers:");
for (int num : numbers) {
	 if (num % 2 == 0) { 
	 int square = num * num;
	System.out.println(square);
	 }
	 }

System.out.println("Squares of odd numbers:");
for (int num : numbers) {
 if (num % 2 != 0) { 
 int square = num * num;
System.out.println(square);
 }
 }

//-------------------------------------------------------------------------------------------------------------	

System.out.println("Numbers from 1 to 10:");
for (int i = 1; i <= 10; i++) {
 System.out.println(i);
}

//-------------------------------------------------------------------------------------------------------------	

int[] n1 = {45, 12, 89, 5, 67, 22, 3};

if (n1.length > 0) {
int res = n1[n1.length - 1];
System.out.println("Last element: " + res);
}

//-------------------------------------------------------------------------------------------------------------	


int sum = 0;
for (int num : numbers) {
      sum += num;
     }
System.out.println("Sum: " + sum);

double average = 0.0;
if (numbers.length > 0) {
      average = (double) sum / numbers.length;
     }
System.out.println("Average: " + average);


int minus = 0;
if (numbers.length > 0) {
    minus = numbers[0];
 for (int i = 1; i < numbers.length; i++) {
 minus -= numbers[i];
     }
   }
 System.out.println("Minus (sequential subtraction): " + minus);

//-------------------------------------------------------------------------------------------------------------	

}
	}