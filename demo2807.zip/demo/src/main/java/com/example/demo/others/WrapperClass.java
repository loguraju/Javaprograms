package com.example.demo.others;

//primitive data types convert into objects
//This is useful when working with collections like ArrayList, which can only store objects—not primitives.
//Ex : int -> Integer

public class WrapperClass {
    public static void main(String[] args) {
        // Primitive to Wrapper (Boxing)
        int a = 10;
        Integer obj = Integer.valueOf(a);  // Explicit boxing
        Integer Boxed = a;                 // Auto-boxing //Java automatically converts the primitive int to an Integer object.

        // Wrapper to Primitive (Unboxing)
        int b = obj.intValue();       // Explicit unboxing     
        int Unboxed = obj;            // Auto-unboxing //Java automatically converts the Integer object to a primitive int.

        System.out.println("Primitive: " + a);
        System.out.println("Boxed: " + obj);
        System.out.println("Unboxed: " + b);
    }
}

