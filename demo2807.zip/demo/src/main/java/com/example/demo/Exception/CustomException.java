package com.example.demo.Exception;

public class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}



