package com.example.demo.others;

//Constructors have the same name as the class with different parameter
//do not have a return type, not even void.

class Car {
    String model;
    int year;

    // Default Constructor (No parameter)
    Car() {
        model = "Unknown";
        year = 0;
    }

    // Parameterized Constructor(With parameter)
    Car(String model, int year) {
        this.model = model;
        this.year = year;
    }

    // Copy Constructor(copy an object with parameter to another object , of the same class)
    Car(Car other) {
        this.model = other.model;
        this.year = other.year;
    }

    void display() {
        System.out.println("Model: " + model + ", Year: " + year);
    }
}

public class Constructor {
    public static void main(String[] args) {
        Car car1 = new Car(); // Default constructor
        Car car2 = new Car("Toyota", 2022); // Parameterized constructor
        Car car3 = new Car(car2); // Copy constructor

        car1.display();
        car2.display();
        car3.display();
    }
}

