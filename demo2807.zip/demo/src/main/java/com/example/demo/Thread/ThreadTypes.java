package com.example.demo.Thread;

//thread is a lightweight subprocess, the smallest unit of processing. 
//Java provides built-in support for multithreaded programming, which allows multiple threads to run concurrently.

public class ThreadTypes {

// Type 1 - extends Thread
    static class MyThread extends Thread {
        public void run() {
            System.out.println("Thread is running...");
        }
    }

// Type 2 - implements Runnable interface
    static class MyRunnable implements Runnable {
        public void run() {
            System.out.println("Runnable thread is running...");
        }
    }

    public static void main(String[] args) {
        MyThread t1 = new MyThread(); // Create thread
        t1.start(); // Start thread

        MyRunnable myRunnable = new MyRunnable();
        Thread t2 = new Thread(myRunnable); // Pass Runnable to Thread
        t2.start(); // Start thread
    }
}
