package com.example.demo.others;

import java.util.concurrent.CopyOnWriteArrayList;

public class FailSafe{
    public static void main(String[] args) {
        CopyOnWriteArrayList<String> list = new CopyOnWriteArrayList<>();
        list.add("A");
        list.add("B");

        for (String s : list) {
            System.out.println(s);
            list.add("C"); // Safe modification
        }

        System.out.println("Final list: " + list);
    }
}
