package com.example.demo.program;

import java.util.*;

public class JavaVowels {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Print the string: ");
		
		String input = scanner.nextLine().toLowerCase();
		
	    List<Character> vow = Arrays.asList('a','e','i','o','u');
		
		long res = input.chars().mapToObj(c->(char)c).filter(vow::contains).count();
		
		System.out.println("Vowels: "+ res );
		
	}

}
