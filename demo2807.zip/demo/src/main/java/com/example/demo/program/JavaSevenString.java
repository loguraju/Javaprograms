package com.example.demo.program;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JavaSevenString {
public static void main(String[] args) {
		
		String original = "Hello Java";
        String reversed = "";

            for (int i = original.length() - 1; i >= 0; i--) {
                  reversed += original.charAt(i);
                    }

 System.out.println("Original: " + original);
 System.out.println("Reversed: " + reversed);
//-------------------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------
 
//-------------------------------------------------------------------------------------------------------------
 
//-------------------------------------------------------------------------------------------------------------
	}

}
