package com.example.demo.jpa;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.jpa.JpaDelete.User;
import com.example.demo.jpa.JpaDelete.UserRepository;

public class JpaUpdate {
	

	//application.properties
    spring.datasource.url=jdbc:h2:mem:testdb
    spring.datasource.driverClassName=org.h2.Driver
    spring.datasource.username=sa
    spring.datasource.password=
    spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
    spring.h2.console.enabled=true
    spring.jpa.hibernate.ddl-auto=update

// 1.Entity Class
	 	@Entity
		@Table(name = "users")
		public class User {
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Long id;
		    private String name;
		    private LocalDate dateOfBirth;
         // Getters and Setters
		}

//2. Repository with Native Insert query
	 public interface UserRepository extends JpaRepository<User, Long> {
		    @Modifying
		    @Transactional
		    @Query(value = "UPDATE users SET name = :name WHERE id = :id", nativeQuery = true)
		    void updateUser(@Param("id") Long id, @Param("name") String name); 
	 	}
	 	
//3. Service or Controller to Call the Insert
	 	@RestController
	 	@RequestMapping("/users")
	 	public class UserController {
	 	    @Autowired
	 	    private UserRepository userRepository;
	 	    
           @PutMapping("/update")
           public String updateUserName(@RequestParam Long id, @RequestParam String name) {
           userRepository.updateUser(id, name);
           return "User name updated successfully!";
            }
	 	  }

		
//4. Test the Endpoint	
	 	http://localhost:8080/users/update?id=1&name=Loganathan

}
