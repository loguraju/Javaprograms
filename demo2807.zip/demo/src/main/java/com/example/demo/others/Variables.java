package com.example.demo.others;

//var+able = value can changeable
public class Variables {

    // Instance variable
	//Declared inside a class but outside any method //Belong to class(specific object)
    int instanceVar = 10;

    // Static variable
    //Declared with the static keyword  //Belong to the class(not to any specific object)
    static int staticVar = 20;

    void display() {
        // Local variable 
    	//Declared inside a method or block //Only accessible within that method/block //Must be initialized before use
        int localVar = 5;

        System.out.println("Local Variable: " + localVar);
        System.out.println("Instance Variable: " + instanceVar);
        System.out.println("Static Variable: " + staticVar);
    }

    public static void main(String[] args) {
    	Variables obj1 = new Variables();
        obj1.display();

        // Accessing static variable directly using class name
        System.out.println("Accessing static variable: " + Variables.staticVar);
    }
}
