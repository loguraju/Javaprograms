package com.example.demo.Exception;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


//EX 1 Throws with customexception
public class TestCustomException {
    public static void checkNumber(int number) throws CustomException {
        if (number < 0) {
            throw new CustomException("Number cannot be negative.");
        } else {
            System.out.println("Valid number: " + number);
        }
    }
    
//EX 2 Throws with IO exception
public static void readFile(String fileName) throws IOException {
        FileReader file = new FileReader(fileName); // May throw IOException
        BufferedReader fileInput = new BufferedReader(file);
        System.out.println(fileInput.readLine());
        fileInput.close();
    }


    public static void main(String[] args) {
        try {
            checkNumber(-5); // This will throw the custom exception
        } catch (CustomException e) {
            System.out.println("Caught exception: " + e.getMessage());
        }
    }
}