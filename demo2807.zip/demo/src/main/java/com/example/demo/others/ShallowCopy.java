package com.example.demo.others;

class Person implements Cloneable {
    String name;

    Person(String name) {
        this.name = name;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone(); // shallow copy ( create new reference and point to same obj)
    }
}

public class ShallowCopy {
    public static void main(String[] args) throws CloneNotSupportedException {
        Person p1 = new Person("Loganathan");
        Person p2 = (Person) p1.clone();

        p2.name = "Raju";

        System.out.println("p1 name: " + p1.name); // Loganathan
        System.out.println("p2 name: " + p2.name); // Raju
    }
}
