package com.example.demo.program;

import java.time.*;
import java.time.format.DateTimeFormatter;
//import java.time.temporal.ChronoUnit;

public class JavaEightEasyDateTime {
	
	public static void main(String[] args) {


//-------------------------------------------------------------------------------------------------------------
		
LocalDate date = LocalDate.now();      
System.out.println("date :" +date);
      
LocalTime time = LocalTime.now();
System.out.println("time :" +time);
      
LocalDateTime dateTime = LocalDateTime.now();
System.out.println("dateTime: " +dateTime);
//-------------------------------------------------------------------------------------------------------------      

LocalDate cdate = LocalDate.of(2025, 6, 18);
System.out.println("custom date :" +cdate);

LocalTime ctime = LocalTime.of(14, 30);
System.out.println("custom time :" + ctime);

//-------------------------------------------------------------------------------------------------------------

LocalDateTime now = LocalDateTime.now();
DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
String cformat = now.format(formatter);
System.out.println("custom format :" + cformat);	
	
//---------------------------------------------------------------------------------------------------------

//Get current date-time with system default time zone
ZonedDateTime zonedNow = ZonedDateTime.now();
System.out.println("Current ZonedDateTime: " + zonedNow);

//Format with custom pattern including zone
DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm z");
String zformat = zonedNow.format(format);
System.out.println("Formatted ZonedDateTime: " + zformat);
	

//Create ZonedDateTime for a specific zone
ZonedDateTime newYorkTime = ZonedDateTime.now(ZoneId.of("America/New_York"));
System.out.println("New York Time: " + newYorkTime.format(formatter));

//-----------------------------------------------------------------------------------------------------------	

//LocalDate date = LocalDate.now(); 

// Get the month as an enum (e.g., JUNE)
Month month = date.getMonth();
System.out.println("Month (Enum): " + month);

// Get the month as a number (1 = January, 12 = December)
int monthValue = date.getMonthValue();
System.out.println("Month (Number): " + monthValue);
    
DayOfWeek day = date.getDayOfWeek(); 
System.out.println("Today is: " + day);

int dayOfMonth = date.getDayOfMonth();
System.out.println("Day of the month: " + dayOfMonth);

int second = time.getSecond();
System.out.println("Current second: " + second);

//----------------------------------------------------------------------------------------------------------

        // Define the date of birth
        LocalDate dob = LocalDate.of(1993,11, 27); // Replace with actual DOB

        // Get the current date
        LocalDate today = LocalDate.now();

        // Calculate the period between DOB and today
        Period age = Period.between(dob, today);

        // Print the age
        System.out.println("Age is: " + age.getYears() + " years " +
                                        age.getMonths()+ " months " +
                                        age.getDays()  + " days");
        
        
//------------------------------------------------------------------------------------------------------------
      //LocalDate birthday =LocalDate.of(1993,11,27);
      //LocalDate today = LocalDate.now();
      //System.out.println("Birthday :" + ChronoUnit.YEARS.between(birthday,today));

//------------------------------------------------------------------------------------------------------------
	}

}
