package com.example.demo.designpattern;


//1. Notification Interface
public interface Notification {
    void notifyUser();
}


//2. sub Notification Classes
public class EmailNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending an Email Notification");
    }
}

public class SMSNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending an SMS Notification");
    }
}

public class PushNotification implements Notification {
    public void notifyUser() {
        System.out.println("Sending a Push Notification");
    }
}

//3.Notification Factory
public class Factory {

    public Notification createNotification(String type) {
        if (type == null || type.isEmpty()) {
            return null;
        }
        switch (type.toUpperCase()) {
            case "EMAIL":
                return new EmailNotification();
            case "SMS":
                return new SMSNotification();
            case "PUSH":
                return new PushNotification();
            default:
                throw new IllegalArgumentException("Unknown notification type: " + type);
        }
    }      
    
}


//4.Client Code
public class Main {
    public static void main(String[] args) {
        NotificationFactory factory = new NotificationFactory();

        Notification notification1 = factory.createNotification("EMAIL");
        notification1.notifyUser();

        Notification notification2 = factory.createNotification("SMS");
        notification2.notifyUser();

        Notification notification3 = factory.createNotification("PUSH");
        notification3.notifyUser();
    }
}
