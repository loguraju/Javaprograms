package com.example.demo.others;

public class TypeCasting {
	
	public static void main(String[] args) {
		
		//Implicit (Widening) Casting - automatic
		int a = 10;
		double b = a; // int to double
		System.out.println(b); // Output: 10.0

		//Explicit (Narrowing) Casting  – Requires manual cast
		double x = 10.5;
		int y = (int) x; // double to int
		System.out.println(y); // Output: 10

	}
	
	
	

}
