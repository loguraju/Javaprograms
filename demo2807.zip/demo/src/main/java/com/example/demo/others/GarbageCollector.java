package com.example.demo.others;

//GC is a part of the Java Virtual Machine (JVM) that automatically removes objects that are no longer use or null
//freeing up memory and preventing memory leaks.

public class GarbageCollector {
	
	    public static void main(String[] args) {
	        // Creating objects
	    	GarbageCollector obj1 = new GarbageCollector();
	    	GarbageCollector obj2 = new GarbageCollector();

	        // Nullifying the reference
	        obj1 = null;

	        // Type 2 - gc() is called after object is created 
	        System.gc();

	        System.out.println("Garbage collection requested.");
	    }

	    // Type 1 - finalize() is called before object is created
	    @Override
	    protected void finalize() throws Throwable {
	        System.out.println("Garbage Collector called and object is deleted.");
	    }
	}

