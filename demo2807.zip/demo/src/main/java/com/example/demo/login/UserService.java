package com.example.demo.login;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

	@Service
	public class UserService {
	    private final Map<String, String> users = new HashMap<>();

	    //create user
	    public UserService() {
	        users.put("john", "1234");
	        users.put("alice", "pass");
	    }

	    
	    //logic
	    public boolean authenticate(String username, String password) {
	        return users.containsKey(username) && users.get(username).equals(password);
	    }
	}

