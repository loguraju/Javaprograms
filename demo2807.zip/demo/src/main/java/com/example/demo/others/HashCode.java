package com.example.demo.others;
import java.util.Objects;

public class HashCode {
public static void main(String[] args) {	
class ExampleHash {

	String name;    
    int id;      
   
    public ExampleHash(String name, int id) 
    {
        this.name = name;
        this.id = id;
    }

	// This  compares whether p4 and p3 refer to the "same object in memory", not whether their contents are equal.
	// Since they are two different objects, this will print false. Hence needs to implement below @override method
	
	// override hashcode & equals method
    
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExampleHash other = (ExampleHash) obj;
		return id == other.id && Objects.equals(name, other.name);	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
}
      ExampleHash p1 = new ExampleHash("Riya", 102);
      ExampleHash p2 = new ExampleHash("Nehan", 101);
      ExampleHash p3 = new ExampleHash("Logu", 100);
      ExampleHash p4 = new ExampleHash("Logu", 100);      
      
      System.out.println("Compare res: " + p4.equals(p3)); 
      }
      
}

/**
if (this == obj)
Checks if both references point to the same object in memory. If yes, they are definitely equal.

if (obj == null)
If the object being compared is null, return false — a non-null object can't be equal to null.

if (getClass() != obj.getClass())
Ensures that both objects are of the exact same class. This is stricter than instanceof and avoids false positives in inheritance hierarchies.

ExampleHash other = (ExampleHash) obj;
Casts the object to your class type so you can access its fields.

return id == other.id && Objects.equals(name, other.name);
Compares the id fields directly (primitive int) and uses Objects.equals() to safely compare name (which is a String and could be null).

**/
