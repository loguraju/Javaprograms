package com.example.demo.Thread;

class MyThread extends Thread {
    public void run() {
        System.out.println("Thread is running...");
        try {
            Thread.sleep(2000); // Timed Waiting
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted.");
        }
        System.out.println("Thread finished.");
    }
}

public class ThreadLifeCycle {
    public static void main(String[] args) {
        MyThread t = new MyThread(); // New
        System.out.println("Thread state after creation: " + t.getState());

        t.start(); // Runnable
        System.out.println("Thread state after start: " + t.getState());

        try {
            Thread.sleep(100); // Give time for thread to enter sleep
            System.out.println("Thread state during sleep: " + t.getState());

            t.join(); // Wait for thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Thread state after completion: " + t.getState()); // Terminated
    }
}
