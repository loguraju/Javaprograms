package com.example.demo.jpa;
import jakarta.persistence.*;
import java.time.LocalDate;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


public class JpaInsert {
	
	
	//application.properties
	        spring.datasource.url=jdbc:h2:mem:testdb
			spring.datasource.driverClassName=org.h2.Driver
			spring.datasource.username=sa
			spring.datasource.password=
			spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
			spring.h2.console.enabled=true
			spring.jpa.hibernate.ddl-auto=update


	// 1.Entity Class
 	@Entity
	@Table(name = "users")
	public class User {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String name;
	    private LocalDate dateOfBirth;
	    // Getters and Setters
	}

	//2. Repository with Native Insert query
 	public interface UserRepository extends JpaRepository<User, Long> {
 	    @Modifying
 	    @Transactional
 	    @Query(value = "INSERT INTO users (name, date_of_birth) VALUES (:name, :dob)", nativeQuery = true)
 	    void insertUser(@Param("name") String name, @Param("dob") LocalDate dateOfBirth);
 	}
 	
 	//3. Service or Controller to Call the Insert
 	@RestController
 	@RequestMapping("/users")
 	public class UserController {

 	    @Autowired
 	    private UserRepository userRepository;

 	    @PostMapping("/insert")
 	    public String insertUser() {
 	        userRepository.insertUser("Loganathan", LocalDate.of(1990, 7, 28));
 	        return "User inserted successfully!";
 	    }
 	}
	
 	//4. Test the Endpoint	
 	http://localhost:8080/users/insert
}
