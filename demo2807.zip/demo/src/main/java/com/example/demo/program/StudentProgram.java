package com.example.demo.program;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;


public class StudentProgram {
	
public static void main(String[] args) {		

		 List<Student> list = Arrays.asList(
		            new Student("Logu", 1,"tamil", 75.5,LocalDate.of(2015, 3, 15)),
		            new Student("Nehan",2,"english", 95.8,LocalDate.of(2015, 2, 13)),
		            new Student("Riya",3,"maths", 81,LocalDate.of(2015, 3, 17)),
		            new Student("Raju",4,"social", 89.6,LocalDate.of(2015, 3, 10)),
		            new Student("Selvi",5, "science", 65.8,LocalDate.of(2015, 3, 18)),
		            new Student("Sriram",8, "english", 35.0,LocalDate.of(2015, 3, 16)),
		            new Student("Ranjith",7, "tamil", 45.7,LocalDate.of(2015, 3, 19))
		        );	
		 
    
    List<Student> jdate = list.stream().sorted(Comparator.comparing(Student::getJoiningDate)).collect(Collectors.toList());	
	System.out.println("Student sorted by joining date: \n"+ jdate);	
	
	String Senior = list.stream().sorted(Comparator.comparing(Student::getJoiningDate)).map(c->c.getName()).findFirst().get();
	System.out.println("\nMost Senior: " + Senior);
	
	String Junior = list.stream().sorted(Comparator.comparing(Student::getJoiningDate).reversed()).map(c->c.getName()).findFirst().get();
	System.out.println("Most Junior: " + Junior);
	        
	List<Student> res = list.stream().filter(s -> s.getId() > 5).collect(Collectors.toList());		 
	System.out.println("\nStudents id > 5: "+  res);	
		 
	List<Student> res1 = list.stream().filter(s -> s.getId() > 3 && s.getName()=="Sriram").collect(Collectors.toList());		 
	System.out.println("\nStudents id > 01  && name with sriram : "+  res1);	
		 
	// min & max
	List<Student> res23 = list.stream().sorted(Comparator.comparing(Student::getId)).limit(3).collect(Collectors.toList());	
	System.out.println("\nStudents MIN 3 ID: "+  res23);
	
	List<Student> res2 = list.stream().sorted(Comparator.comparing(Student::getId).reversed()).limit(3).collect(Collectors.toList());
	System.out.println("\nStudents MAX 3 ID: "+  res2);	

    Student res3 = list.stream().sorted(Comparator.comparing(Student::getId)).findFirst().get();    		 
    System.out.println("\nStudents MAX ID: "+  res3);		 
		 
    Student re3 = list.stream().sorted(Comparator.comparing(Student::getId).reversed()).findFirst().get();    
    System.out.println("\nStudents MIN ID: "+  re3);
    
    /**  
    //Percentage
    OptionalDouble min = list.stream().mapToDouble(Student::getPercentage).min(); 
    System.out.println("\nStudent Min Percentage: "+ min);
    
    OptionalDouble max = list.stream().mapToDouble(Student::getPercentage).max(); 
    System.out.println("\nStudent Min Percentage: "+ max);
    
    OptionalDouble average = list.stream().mapToDouble(Student::getPercentage).average(); 
    System.out.println("\nStudent Average Percentage: "+ min);    
 **/   
    
   
    Double HP = list.stream().max(Comparator.comparingDouble(Student::getPercentage)).map(e->e.getPercentage()).get();
    System.out.println("\nStudent Highest Percentage: "+ HP);
    
    Double LP = list.stream().max(Comparator.comparingDouble(Student::getPercentage)).map(e->e.getPercentage()).get();
    System.out.println("\nStudent Lowest Percentage: "+ LP);
    
    Double AP = list.stream().mapToDouble(Student::getPercentage).average().orElse(0); 
    System.out.println("\nStudent Average Percentage: "+ AP);    

    		 
	//Students who scored > 60	 		 
    Map<Boolean, List<Student>> r1 = list.stream()
		                      .collect(Collectors.partitioningBy(student -> student.getPercentage() > 80));		 
    System.out.println("\nStudents who scored above 80:"+ r1.get(true));    	        
	         		       	    		   
		    		   
   //get the name and percentage of each student       
   Map<String, Double> r3 = list.stream().collect(Collectors.toMap(Student::getName, Student::getPercentage));		  
   System.out.println("\nGet the name and percentage of each student: "+ r3);
		       
		       
	//get the subjects offered in the college
	List<String> r4 = list.stream().map(Student::getSubject).distinct().collect(Collectors.toList());
	System.out.println("\nGet the subjects offered in the college: "+ r4);

	       
	//total number of students from the given list of students
	Long r5 = list.stream().collect(Collectors.counting());
	System.out.println("\nTotal number of students from the given list of students: "+ r5);
		        
	//get the students grouped by subject 	            
	Map<String, List<Student>> r6 = list.stream().collect(Collectors.groupingBy(Student::getSubject));
    System.out.println("\nGet the students grouped by subject : "+ r6);

}  
  
}