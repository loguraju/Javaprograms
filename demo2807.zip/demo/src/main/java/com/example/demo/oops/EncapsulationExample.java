package com.example.demo.oops;


//Class with encapsulation
	class BankAccount {
	    // Private data members
	    private String name;

	    // Public getter method for name
	    public String getName() {
	        return name;
	    }

	    // Public setter method for name
	    public void setName(String name) {
	        this.name = name;
	    }

}

// Main class
	public class EncapsulationExample {
	    public static void main(String[] args) {
	    	BankAccount s = new BankAccount();

	        // Setting values using setters
	        s.setName("Loganathan");	       

	        // Getting values using getters
	        System.out.println("Name: " + s.getName());
	    }
	}

