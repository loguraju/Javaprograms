package com.example.demo.designpattern;

/// Singleton class
public class Singleton {
    
     // Step 1: Create the instance eagerly
     private static final Singleton instanceEasy = new Singleton(); // Eager initialization (class load)
    
     
    // Step 1: Create a private static instance of the class
     private static Singleton instance;

    // Step 2: Make the constructor private so that this class cannot be instantiated
    private Singleton() {
        System.out.println("Singleton instance created.");
    }

    // Step 3: Provide a public static method to get the instance
    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton(); // Lazy initialization ( when getInsrance called
        }
        return instance;
    }

    // Example method
    public void showMessage() {
        System.out.println("Hello from Singleton!");
    }
}
