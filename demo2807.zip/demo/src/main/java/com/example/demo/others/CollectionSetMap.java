package com.example.demo.others;

import java.util.*;
import java.util.Map;

public class CollectionSetMap {	
	public static void main(String[] args) {
		
	List<String> li = new ArrayList<>();
	
	li.add("black"); //Create
	li.add("white");
	li.add("blue");
	li.add("yellow");
	li.add("gray");
	li.add("green");
	li.add("red");
	li.add("red");
	//li.add(null); //tree set will not allow null value
	System.out.println("list add:" + li);   
	
	li.remove("blue");  //Delete
	li.remove(1);
	System.out.println("list remove:" + li); 
	
	li.set(1, "orange");	//Update
	System.out.println("list update:" + li); 
	
	String get = li.get(0);   //Get
	System.out.println("list get:" + get);	
	
			
//Convert to Set to remove duplicates WITH Un order
Set<String> HS = new HashSet<>(li);
System.out.println("Unique list with UO : " + HS);

//Convert to LHS to remove duplicates WITH Insert order
Set<String> LHS = new LinkedHashSet<>(li);
System.out.println("Unique list with IO : " + LHS);

// Convert to Set to remove duplicates WITH Assessing order
Set<String> TS = new TreeSet<>(li);
System.out.println("Unique list with AO : " + TS);

//------------------------------------------------------------

//All map will allow dublicate vaules 

Map<String, Integer> list = new HashMap<>(); // hash map will allow null key once // UO 
list.put("Apple", 1);
list.put("Banana", 2);
list.put("Orange", 3);
list.put("Apple",4);
list.put("Lemon",4);
list.put("Mango",4);


Map<String, Integer> Treedmap = new TreeMap<>(list); // tree map will not allow null key // AO 
System.out.println("Tree Map Result: " + Treedmap);

list.put(null,7);
list.put(null,9);

System.out.println("Map Result: " + list);

Map<String, Integer> Linkedmap = new LinkedHashMap<>(list); // linked hash map will allow null key once // IO 
System.out.println("Linked Map Result: " + Linkedmap);

//All map will allow Duplicate value & null value
	}

}
