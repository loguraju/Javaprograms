package com.example.test;

import java.util.*;
import java.util.stream.*;

public class Test {

	public static void main(String[] args) {

		 int[] a11 = {1, 2, 4, 6,8};
		 
		 int min = Arrays.stream(a11).min().orElse(0);
		 int max = Arrays.stream(a11).max().orElse(0);
		 
		 
		  
		
		 
	}

}
